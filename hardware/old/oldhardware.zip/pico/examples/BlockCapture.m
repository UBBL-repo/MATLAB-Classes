format short
clear all;
close all;
clc;



addpath(genpath('C:/MATLAB/hardware'));
addpath(genpath('C:\MATLAB\inc'));
delete(instrfind);
%global constants
PreTrig = 0;
PostTrig = 500;
NumAq = 10;

%------- Connect Picoscope -------

PS5000aConfig;                                                    %connect to PS5000aConfig
ps5000aDeviceObj1 = icdevice('picotech_ps5000a_generic.mdd', ''); %connect pico
connect(ps5000aDeviceObj1);                                       %connect pico
[status1.setResolution, scope1.resolution] = ...
    invoke(ps5000aDeviceObj1,'ps5000aSetDeviceResolution', 16);   %set resolution 15

set(ps5000aDeviceObj1, 'numPreTriggerSamples',PreTrig); %pretrigger sample
set(ps5000aDeviceObj1, 'numPostTriggerSamples',PostTrig); %posttrigger sample

    % Set Trigger for Picoscope
    % Channel     : 4 (PS5000A_CHANNEL_=EXT)
    % Threshold   : 100 (mV)
    % Direction   : 1 (Falling)
    % Delay       : 0
    % Auto trigger: 0 (wait for 0 second)
[status] = invoke(ps5000aDeviceObj1, 'setSimpleTrigger', 4, 100, 1, 0, 0);

%--------------------------------


set(ps5000aDeviceObj1, 'numPreTriggerSamples',PreTrig); %pretrigger sample 1024
set(ps5000aDeviceObj1, 'numPostTriggerSamples',PostTrig); %posttrigger sample 1024





% Channel     : 4 (PS5000A_CHANNEL_=EXT)
% Threshold   : 100 (mV)
% Direction   : 1 (Falling)
% Delay       : 0
% Auto trigger: 0 (wait for 0 second)
[status] = invoke(ps5000aDeviceObj1, 'setSimpleTrigger', 4, 100, 1, 0, 0);



figure(1)


while true
    
    Voltage = zeros(PreTrig+PostTrig, 1);
    
    for i = 1:NumAq
    
% Capture a block of data:
%
% segment index: 0

[status] = invoke(ps5000aDeviceObj1, 'runBlock', 0);

% GET TIMEBASE
% Driver default timebase index used - use ps5000aGetTimebase or
% ps5000aGetTimebase2 to query the driver as to suitability of using a
% particular timebase index then set the 'timebase' property if required.
% timebase     : 65 (default)
% segment index: 0
[status, timeIntervalNanoSeconds, maxSamples] ...
    = invoke(ps5000aDeviceObj1, 'ps5000aGetTimebase', 65, 0);

% Retrieve data values:
%
% start index       : 0
% segment index     : 0
% downsampling ratio: 1
% downsampling mode : 0 (PS5000A_RATIO_MODE_NONE)
[scope1.chA, ~, ~, ~, numSamples, scope1.overflow] = ...
    invoke(ps5000aDeviceObj1, 'getBlockData', 0, 0, 3, 0);

timeNs = double(timeIntervalNanoSeconds) * double([0:numSamples - 1]);
timeMs = timeNs / 1e6;



% Channel A
plot(timeMs, abs(scope1.chA), 'b');
title('Channel A');
xlabel('Time (ms)');
ylabel('Voltage (mV)');
drawnow





    end
    


end
