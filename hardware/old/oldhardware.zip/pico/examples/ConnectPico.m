clc;
close all;
clear;
delete( instrfind ); %disconnect all
addpath(genpath('C:/MATLAB/hardware'));
addpath(genpath('C:\MATLAB\inc'));
PS5000aConfig; %connect to PS5000aConfig

ps5000aDeviceObj1 = icdevice('picotech_ps5000a_generic.mdd', ''); %connect pico
connect(ps5000aDeviceObj1); %connect pico
[status1.setResolution, scope1.resolution] = ...
    invoke(ps5000aDeviceObj1,'ps5000aSetDeviceResolution', 15); %set resolution 15