clc;
close all;
clear;
delete( instrfind );
addpath(genpath('C:/MATLAB/hardware'));
PS5000aConfig;

ps5000aDeviceObj1 = icdevice('picotech_ps5000a_generic.mdd', '');
connect(ps5000aDeviceObj1);
[status1.setResolution, scope1.resolution] = ...
    invoke(ps5000aDeviceObj1,'ps5000aSetDeviceResolution', 15);


set(ps5000aDeviceObj1, 'numPreTriggerSamples', 0);
set(ps5000aDeviceObj1, 'numPostTriggerSamples', 10000);
status1.ps5000aRunBlock = invoke(ps5000aDeviceObj1, 'ps5000aRunBlock', 0);

scope1.ready = PicoConstants.FALSE;

while (scope1.ready == PicoConstants.FALSE)
    
    [status1.ready, scope1.ready] = invoke(ps5000aDeviceObj1, 'ps5000aIsReady');
    
    
    pause(0.01);
    
end

[scope1.chA, ~, ~, ~, scope1.numSamples, scope1.overflow] = ...
    invoke(ps5000aDeviceObj1, 'getBlockData', 0, 0, 1, 0);

plot(linspace(0,1,length(scope1.chA)), scope1.chA)